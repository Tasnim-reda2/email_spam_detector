import streamlit as st
import pickle
import re
from nltk.corpus import stopwords

# Load the trained model and TF-IDF vectorizer
with open('spam_classifier_model.pkl', 'rb') as f:
    model = pickle.load(f)

with open('tfidf_vectorizer.pkl', 'rb') as f:
    vectorizer = pickle.load(f)

# Load stopwords
stop_words = set(stopwords.words('english'))

# Function to clean the input text
def clean_text(text):
    text = str(text).lower()
    text = re.sub(r'[^a-z\s]', '', text)
    text = ' '.join(word for word in text.split() if word not in stop_words)
    return text

# Streamlit UI
st.title("📧 Email Spam Detector")
st.write("Enter your email content below to check whether it's Spam or Not Spam.")

input_email = st.text_area("Enter your email text here:")

if st.button("Analyze"):
    cleaned = clean_text(input_email)
    vect_text = vectorizer.transform([cleaned])
    prediction = model.predict(vect_text)[0]

    if prediction == 1:
        st.error("📛 The email is classified as: Spam")
    else:
        st.success("✅ The email is classified as: Not Spam")
