import pandas as pd
import re
import nltk
import pickle
from nltk.corpus import stopwords
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report

# تحميل stopwords
nltk.download('stopwords')
stop_words = set(stopwords.words('english'))

# تحميل الداتا
df = pd.read_csv(r"C:/Users/Acer/Desktop/enron_spam_data.csv")

# اختيار العمودين المهمين فقط وإعادة تسميتهم
df = df[['Spam/Ham', 'Message']]
df.columns = ['label', 'message']

# تنظيف النصوص
def clean_text(text):
    text = str(text).lower()
    text = re.sub(r'[^a-z\s]', '', text)
    text = ' '.join(word for word in text.split() if word not in stop_words)
    return text

df['cleaned'] = df['message'].apply(clean_text)

# تحويل التصنيفات إلى أرقام
df['label'] = df['label'].map({'ham': 0, 'spam': 1})

# إزالة الصفوف اللي فيها بيانات ناقصة
df.dropna(inplace=True)

# تقسيم البيانات
X_train, X_test, y_train, y_test = train_test_split(
    df['cleaned'], df['label'], test_size=0.2, random_state=42
)

from sklearn.feature_extraction.text import TfidfVectorizer

# تحويل النصوص إلى خصائص عددية باستخدام TF-IDF
vectorizer = TfidfVectorizer(max_features=5000)
X_train_vec = vectorizer.fit_transform(X_train)
X_test_vec = vectorizer.transform(X_test)


model = MultinomialNB()
model.fit(X_train_vec, y_train)



y_pred = model.predict(X_test_vec)

print("Accuracy:", accuracy_score(y_test, y_pred))
print("Confusion Matrix:\n", confusion_matrix(y_test, y_pred))
print("Classification Report:\n", classification_report(y_test, y_pred))



# حفظ النموذج و TF-IDF إلى ملفات
with open('spam_classifier_model.pkl', 'wb') as f:
    pickle.dump(model, f)

with open('tfidf_vectorizer.pkl', 'wb') as f:
    pickle.dump(vectorizer, f)



